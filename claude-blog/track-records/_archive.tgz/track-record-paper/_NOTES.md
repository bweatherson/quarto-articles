# _NOTES: paper on what a track record can show (testing experts) -- working title TBD

Started 2026-10-20 (after the Stein project was parked: stein-paper/REPORT.md).
Process (BW's): (1) idea from research; (2) advisor; (3) rough draft; (4) 10-agent Q&A; (5) triage;
(6) Quarto paper < 6000 words with checked .bib; (7) screening per claude-blog/CLAUDE.md
(copy: /mnt/user-data/outputs/_standard/CLAUDE-blog.md).
Process changes from lessons of the two parked projects: (a) run a predictability (go/no-go) test on my own
abstract BEFORE the advisor; (b) check my own numbers against my thesis before a memo goes out; (c) priority
checks in neighbouring fields (economics, CS/ML, statistics) from the start.

## Human-input log
- 2026-10-20, BW: chose the subject ("Unless something radical turns up, I think it's time to go to the track
  record paper") -- item 3 on Claude's scouting shortlist ("What a track record can show: testing experts against
  strategic ignorance"; scout report: stein-paper/research/scouting/scout-formal-epistemology.md §1).
  PERMITTED (choosing topic). The subject and the two thesis sketches in the scout report (counterfactual
  commitment; comparative only) were proposed by a Claude scouting agent, not by BW.

## Log
- Existing claude-blog papers checked for overlap: none on testing experts. "Findable, Not Simple" uses a
  cryptographic-assumption argument (cf. Fortnow & Vohra 2009 on computationally bounded charlatans) -- avoid
  duplicating its method or thesis.
- 2026-10-20: econ/CS report received (research/econ-report.md, 17k words; ~40 extracts in research/texts/).
  Core: prior-free, single-expert tests of REALIZED forecasts are manipulable (Sandroni 2003; O&S 2008 future-
  independent; Shmaya 2008 Borel prequential; O&S 2009 MOR any test with bounded data). Positive results need:
  commitment to future/counterfactual predictions (Dekel-Feinberg 2006; O&S 2009 AoS), unbounded data, a tester
  prior (Stewart 2011: then the test measures value added over the tester's own forecasts), restricted (non-convex /
  learnable) classes, an informed rival (AW 2008; FS 2008), computational limits (Fortnow-Vohra; Hu-Shmaya).
  Non-manipulability is only topological (O&S 2009 MOR Prop 3). Engine: minimax + "reducibility" (Nature's
  mixtures are themselves processes the expert can announce) -- AW §6. Economists' own philosophical claims
  (verbatim in report §11.6): O&S 2011 "falsifiability has no power to distinguish ..."; AW "the only coherent
  notion of 'true' probabilities is relative"; Olszewski 2015 "this literature is about the philosophy of science";
  O&S 2009 AoS "difficulty for the prequential principle"; Seidenfeld 1985 calibration is "internal".
  Pomatto & Sandroni 2018 (Phil Sci) is on Bayesian orgulity (sigma-additivity), cites Weatherson 2015.
  NB: BW has published in the orgulity debate (Weatherson 2015) -- the user is expert in an adjacent debate.
- Closest econ links to the orgulity debate: Pomatto, Al-Najjar & Sandroni 2014 (AoS): testability <-> Blackwell-
  Dubins merging; Al-Najjar, Pomatto & Sandroni 2014 "Claim Validation" (AER, abstract only): skeptical experts can
  evade rejection, experts required to accept well-supported claims can be tested; Stewart 2011: prior-free type-I
  control "arises only if the tester has an extreme form of ambiguity aversion". So "testing needs orgulity/priors"
  is largely in the econ literature already; any modesty-vs-deference thesis must go beyond these.
- 2026-10-20: philosophy report received (research/philosophy-report.md, 11.5k words). Priority: no philosophy
  paper uses the manipulability results to argue about what track records show about expertise. Near-precursors:
  Seidenfeld 1985 (calibration "otiose"; one-note weatherman; asks for a short-range criterion separating expert
  from duffer, p. 284); Shieber 2015 (Testimony textbook, pp. 82-84, uses O&S 2011 against reputation-based
  accounts -- NOT READ); Grodniewicz 2022 fn 21 (reply); Roth, Tolbert & Weinstein 2023 (FAccT; Sandroni stated,
  reference-class framing); Fan 2026 Synthese (strategic track-record building; Bayesian persuasion; no
  randomizing charlatans); Huang 2023 BJPS (track records can fail even with God's-eye view; non-strategic);
  Herrmann 2022 Synthese (prediction with expert advice for novices); Schurz meta-induction; Levy 2025 Erkenntnis
  (criteria extend trust rather than ground it). Belot 2013 SPL (failure of calibration typical) sets FV aside.
  Agent's observation: the same minimax/approachability that makes absolute tests manipulable underwrites regret
  bounds / meta-inductive optimality (not found in the meta-induction literature).
- My thinking (pre-memo): every route ends in "certification is relative" (AW's own conclusion). Candidate
  philosophical theses: S2 "trust extended, not grounded" (Levy + fields untestable + parasites/calibeating);
  S3 "expertise is not behavioural" (Blockhead/psychologism; AI evaluation) -- caveat: O&S 2009 MOR shows even
  model commitment (future-dependent tests) is manipulable with bounded data; S4 "the social cost of modesty"
  (orgulity <-> testability; ANPS 2014 Claim Validation, PAS 2014, Pomatto & Sandroni 2018, Belot, Weatherson
  2015). Rejected on reflection: "information not insight" (dissolves into Bayesian model averaging: a coherent
  agent CAN learn that a method she entertains beats her old one); "Humean chance escapes the theorems"
  (non-convexity helps only with infinite data; finite-data tests still manipulable by closure); "meta-induction
  is charlatanry" (Schurz never claims certification).
- Process: run a slate-level predictability test FIRST (two independent testers given only the econ results and
  the list of philosophical debates, asked for the most natural papers) to see whether S2-S4 are the obvious ones.
- Slate predictability test A (slate-prediction-A.md): S2 = the most natural paper (MATCH, 7P/1D) and overstated
  ("no performance-based solution" false: AW solves the 2-expert case given one informed; computability escape
  omitted; Levy's slogan vindicated but his access-based reason not -- and U1 reverses it; field claim needs
  qualification: AW Thm 7 finite horizon, O&S PNAS not read). S3 Blockhead frame inverted (charlatan's
  counterfactual dispositions DIFFER; only test verdicts coincide; repaired: "expertise is modal, not actualist",
  anti-Blockhead). S4 false in sigma-additive setting (orgulous opinions still face manipulable prequential /
  bounded-data tests; orgulity matters only in PAS's finitely additive extension). Tester's own non-obvious theses:
  U1 "it takes a non-expert to certify an expert" (Stewart: true expert fails w.p. eps = tester's chance of
  learning the truth herself; AW Thm 2 needs diffuse prior) -- inverts "it takes one to know one", Charmides,
  Nguyen, Levy's reason; U2 the theorems concern test-aware optimisation, not ignorance (sincere non-experts fail
  except on negligible sets: Dekel-Feinberg Thm 3, Stewart Cor 1) -- exact for models trained against the metric;
  U3 metaphysics of chance (reducibility needs chances closed under mixture; Humean chances are not) -- I had
  this idea too (C5), set aside because non-convexity helps only with unbounded data.
- Slate predictability test B (slate-prediction-B.md): S2 MATCH with its #1 (only one worth pursuing, after fixes);
  S3 not as framed (3 of 4 rescue routes behavioural; "psychologistic" wrong); S4 already in ANPS/PAS and costless
  (BD-twin argument: any opinion has a sigma-additive twin agreeing on all finite histories). B's own most
  surprising thesis: "Ignorance of chance looks like chance": with bounded data, screening the ignorant requires a
  NON-CONVEX protected class (MOR Prop 1 contrapositive; Sandroni-Shmaya Prop 1); a mixture is what an ignoramus
  and an honest coarse expert both forecast; so finite records certify only sharp knowledge, never modest/coarse
  expertise. (Converges with my C5 and A's U3.)
- My synthesis (T**): two kinds of expertise (Hall 2004 database vs analyst -- VERIFY Hall's terms): information
  (knowing more) vs judgment (reasoning better from the same evidence). (i) Prior-free finite tests certify neither
  absolutely, except sharp foreknowledge relative to a non-convex class (= information relative to the class's
  hull); protecting all honest learners over a model class protects its convex hull -> manipulable (MOR Prop 1).
  (ii) A Bayesian evaluator certifies informational expertise relative to her prior (Stewart; better the less she
  knows: A's U1), but never judgment superior to her own: if the other's method has weight w in her prior, the
  other's LR against her is <= 1/w on EVERY path (mixture bound); if not, Ville says she is near-certain it won't
  beat her, and Stewart says false experts pass w.p. 0 by her lights. (iii) Judgment is certifiable only
  comparatively between others (LR picks the KL-closer forecaster; caveats: parasitism/calibeating, AW Thm 1).
  Upshot: you can learn that someone knows more than you, not that she reasons better than you; recognising
  better judgment is third-personal / institutional (tournaments), and first-person deference to it needs
  non-conditionalising self-doubt (higher-order evidence).
- Memo v1 check by tester B (memo1-check-B.md): EXPECTED, and the Hall information/judgment line FAILS: (1)
  inconsistent with claim 2 (Stewart certifies someone who knows the chances); AW's representation point -- the
  same forecasts are information or judgment depending on the evaluator's uncertainty; (2) for non-ideal
  evaluators superior computation is certifiable (all advertised cases move to the information side); (3) breaking
  cases: doctor certifies doctor by agreement ("non-doctor better placed" is an artefact of Stewart's quack knowing
  the evaluator's prior); dogmatic i.i.d. modeller rightly concludes a Markov forecaster judges better; LLMs have
  database expertise. Formal corrections: 1/w bound only for ATOMS (smooth priors: LR can grow ~ n^{d/2});
  "false experts pass w.p. 0" only for history-measurable forecasters, by the evaluator's lights, infinite horizon;
  "knows least" conflates diffuse with mistaken; LR-picks-KL-closer needs forecasts bounded away from 0/1 and a
  growing KL gap (Kavaler-Smorodinsky). The one possibly new piece REVERSES claim 3: another's likelihood ratio
  against one's own forecasts is a test martingale under one's own forecasts (Ville), so one can reject one's own
  forecasts at level 1/c, and by one's own lights no charlatan can game it: a novice CAN recognise being out-judged.
- My reaction: the self-test gives a person-level refutation/verification asymmetry: a truthful expert cannot be
  made to fail a test of her forecasts against ANYONE's (prior-free; Ville under the truth; cf. AW Thm 1), while no
  record certifies anyone. Records refute persons, never verify them -- and the person a novice can most usefully
  refute is herself (Socratic: Charmides 170e-171c, knowledge of what one does not know). Caveat: O&S 2011 already
  argue "refutation is a better maxim than verification" (for theories/contracts); AW: only relative truth;
  game-theoretic probability (Shafer-Vovk: Skeptic's capital is a test martingale) is the standard home of the
  self-test.
- Memo v1 check by tester A (memo1-check-A.md): formal core predictable; headline false (contradicts claim 2;
  the first/third-person asymmetry comes from switching standards: "by her lights" vs "under the truth"); the
  learners -> convex-hull lemma is "the one nice lemma" (needs compactness; unbounded charlatans; MOR Prop 2
  mis-cited); salvage idea: "orgulity hides better judgment" (modest evaluators, orgulous experts) -- unverified.
- My further check of the lemma: in MOR Prop 1 with paradigm conv(C) the manipulating charlatan randomises over
  conv(C), i.e. he knows C -- which the test itself builds in. So the lemma says hedgers over C are
  indistinguishable from someone who knows only what the test embodies (near-tautology, as B said). General
  moral: a public test cannot certify knowledge it builds in; certification is always of knowledge beyond the
  evaluator's baseline (AW/Stewart again). DROPPED as a headline.
- Memo v1 ABANDONED. Next: memo v2 on the one piece both testers found new-ish and that survives both standards:
  person-level refutation. Ville under the truth (prior-free): if F's forecasts are the chances, any rival's LR
  against F (any strategy, randomised, even seeing F's forecasts) is a test martingale, so P(F ever beaten by
  factor c) <= 1/c. Records can refute anyone's claim to know the chances -- including one's own -- charlatan-
  proof and prior-free; they can verify no one's. Same computation by her lights and under the truth (no
  standard switching).
- Advisor round 1 (advisor-report-v1.md; code/advisor-v1-refutation-sim.py): VERDICT (A); recommends PARKING
  THE SUBJECT. Person-level refutation is in Shafer 2023 (NEJSDS 2(2) §2.2: "Too many predictions contradicted by
  experience discredit the person making them ... you are not much of an expert about it") and Shafer 2021 (JRSS A,
  Protocol 4); AW call the martingale property "a standard observation"; Kavaler-Smorodinsky's "error-free" axiom;
  refute/verify asymmetry for sharp hypotheses = Genin & Kelly 2017; anytime-valid comparative e-tests = Henzi &
  Ziegel 2022, Choe & Ramdas 2024; AA = defensive forecasting (Chernov, Kalnishkan, Zhdanov & Vovk 2008).
  The asymmetry again came from switching standards (verification judged against STRATEGIC forecasters,
  refutation against SINCERE ones; against strategic ones refutation fails too: a Bayes mixture of rivals is never
  refuted -- 0/500 runs). The refuted claim ("I know the chances") is one no novice holds; coarse experts are
  refuted 99.9% of the time. Charmides moral inverted (171c: the fellow craftsman can tell -- AW/FS vindicate
  Socrates); self-knowledge of ignorance is the Apology. Only sound paper: S2, ceiling EXPECTED (Episteme/
  Synthese), not competitive. Process lesson: fix one standard per claim before testing an asymmetry.
- 2026-10-20 ~22:30: PROJECT PARKED pending BW (REPORT.md). Alerting BW per instruction ("if you abandon ... alert
  me and we can workshop a different subject").
